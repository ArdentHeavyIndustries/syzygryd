#ifndef _EXT_TRACK_H_
#define _EXT_TRACK_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_TRACK_H_ */
